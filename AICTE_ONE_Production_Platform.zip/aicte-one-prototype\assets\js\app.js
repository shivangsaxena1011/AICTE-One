/**
 * AICTE ONE - Master Application Controller
 * Router, Event Bus, Modal System, Toast Notifications, Role Switcher & Module Dispatcher
 */
const App = {
  currentRoute: 'overview',
  currentParam: null,
  currentRole: null,

  modules: {
    'overview': () => OverviewModule,
    'institutions': () => InstitutionsModule,
    'digitalTwin': () => DigitalTwinModule,
    'applications': () => ApplicationsModule,
    'scrutiny': () => ScrutinyModule,
    'evc': () => EvcModule,
    'verification': () => VerificationModule,
    'compliance': () => ComplianceModule,
    'complaints': () => ComplaintsModule,
    'coordination': () => CoordinationModule,
    'tasks': () => TasksModule,
    'graph': () => GraphModule,
    'copilot': () => CopilotModule,
    'reports': () => ReportsModule,
    'notifications': () => NotificationsModule,
    'audit': () => AuditModule,
    'settings': () => SettingsModule
  },

  async init() {
    this.initRole();
    this.setupNavigation();
    this.setupGlobalSearch();
    this.setupModals();
    await ApiService.checkBackendHealth();
    this.updateBackendStatusIndicator();
    this.updateNotificationBadge();

    // Check URL hash for initial route
    const hash = window.location.hash.replace(/^#\/?/, '');
    if (hash) {
      const [route, param] = hash.split('/');
      this.navigate(route || 'overview', param || null, false);
    } else {
      this.navigate('overview', null, false);
    }

    window.addEventListener('hashchange', () => {
      const currentHash = window.location.hash.replace(/^#\/?/, '');
      const [route, param] = currentHash.split('/');
      if (route && (route !== this.currentRoute || param !== this.currentParam)) {
        this.navigate(route, param || null, false);
      }
    });

    console.log('AICTE ONE Platform initialized in dual-mode.');
  },

  initRole() {
    const saved = localStorage.getItem('aicte_current_role');
    if (saved) {
      try {
        this.currentRole = JSON.parse(saved);
      } catch (e) {
        this.currentRole = SettingsModule.roles[0];
      }
    } else {
      this.currentRole = {
        id: 'ADMIN',
        name: 'System Administrator',
        email: 'admin@aicte-india.org',
        bureau: 'Central Administration',
        perms: 'Full Administrative & Configuration Access'
      };
    }
    this.updateRoleDisplay();
  },

  getCurrentRole() {
    return this.currentRole;
  },

  setCurrentRole(role) {
    this.currentRole = role;
    localStorage.setItem('aicte_current_role', JSON.stringify(role));
    this.updateRoleDisplay();
  },

  updateRoleDisplay() {
    const el = document.getElementById('header-role-name');
    if (el && this.currentRole) {
      el.textContent = this.currentRole.name;
    }
    const emailEl = document.getElementById('header-role-email');
    if (emailEl && this.currentRole) {
      emailEl.textContent = this.currentRole.email;
    }
  },

  updateBackendStatusIndicator() {
    const pill = document.getElementById('backend-status-pill');
    if (!pill) return;
    const isLive = ApiService.isBackendConnected();
    pill.className = `flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-semibold ${isLive ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'}`;
    pill.innerHTML = `
      <span class="w-2 h-2 rounded-full ${isLive ? 'bg-emerald-600' : 'bg-amber-600'}"></span>
      ${isLive ? 'FastAPI Connected' : 'Browser Offline Mode'}
    `;
  },

  setupNavigation() {
    document.querySelectorAll('[data-route]').forEach(link => {
      link.addEventListener('click', (e) => {
        e.preventDefault();
        const route = link.getAttribute('data-route');
        const param = link.getAttribute('data-param') || null;
        this.navigate(route, param);
      });
    });
  },

  navigate(route, param = null, updateHash = true) {
    if (!this.modules[route]) {
      console.warn(`Module '${route}' not found. Defaulting to overview.`);
      route = 'overview';
    }

    this.currentRoute = route;
    this.currentParam = param;

    if (updateHash) {
      window.location.hash = param ? `#/${route}/${param}` : `#/${route}`;
    }

    // Update active nav styling
    document.querySelectorAll('.nav-item').forEach(item => {
      const itemRoute = item.getAttribute('data-route');
      if (itemRoute === route) {
        item.classList.add('nav-active');
      } else {
        item.classList.remove('nav-active');
      }
    });

    // Close mobile sidebar if open
    const sidebar = document.getElementById('sidebar');
    if (sidebar && sidebar.classList.contains('mobile-open')) {
      sidebar.classList.remove('mobile-open');
    }

    // Render target module
    const moduleGetter = this.modules[route];
    if (moduleGetter) {
      const module = moduleGetter();
      if (module && typeof module.render === 'function') {
        module.render('main-content', param);
      }
    }

    window.scrollTo({ top: 0, behavior: 'smooth' });
  },

  async updateNotificationBadge() {
    const badge = document.getElementById('notification-badge');
    if (!badge) return;
    try {
      const res = await ApiService.getNotifications();
      const unread = (res.items || []).filter(n => !n.is_read).length;
      if (unread > 0) {
        badge.textContent = unread > 99 ? '99+' : unread;
        badge.classList.remove('hidden');
      } else {
        badge.classList.add('hidden');
      }
    } catch (e) {
      badge.classList.add('hidden');
    }
  },

  setupGlobalSearch() {
    const input = document.getElementById('global-search-input');
    const resultsBox = document.getElementById('global-search-results');
    if (!input || !resultsBox) return;

    let debounceTimer = null;
    input.addEventListener('input', (e) => {
      clearTimeout(debounceTimer);
      const query = e.target.value.trim();
      if (query.length < 2) {
        resultsBox.classList.add('hidden');
        resultsBox.innerHTML = '';
        return;
      }

      debounceTimer = setTimeout(async () => {
        const instRes = await ApiService.getInstitutions({ search: query, limit: 5 });
        const appRes = await ApiService.getApplications({ search: query, limit: 5 });

        const institutions = instRes.items || [];
        const applications = appRes.items || [];

        if (institutions.length === 0 && applications.length === 0) {
          resultsBox.innerHTML = `<div class="p-3 text-xs text-slate-400">No matching institutions or applications found</div>`;
          resultsBox.classList.remove('hidden');
          return;
        }

        resultsBox.innerHTML = `
          ${institutions.length > 0 ? `
            <div class="p-2 border-b border-slate-100 bg-slate-50 text-[11px] font-bold text-slate-500 uppercase">Institutions</div>
            ${institutions.map(i => `
              <div class="p-2.5 hover:bg-slate-100 cursor-pointer flex justify-between items-center text-xs" onclick="App.selectSearchResult('digitalTwin', '${i.id}')">
                <div>
                  <div class="font-bold text-navy-900">${i.name}</div>
                  <div class="text-[11px] text-slate-500 font-mono">${i.permanent_id} &bull; ${i.city}, ${i.state}</div>
                </div>
                <span class="badge badge-neutral text-[10px]">${i.category}</span>
              </div>
            `).join('')}
          ` : ''}

          ${applications.length > 0 ? `
            <div class="p-2 border-b border-slate-100 bg-slate-50 text-[11px] font-bold text-slate-500 uppercase">Approval Applications</div>
            ${applications.map(a => `
              <div class="p-2.5 hover:bg-slate-100 cursor-pointer flex justify-between items-center text-xs" onclick="App.selectSearchResult('scrutiny', '${a.application_number}')">
                <div>
                  <div class="font-bold text-navy-900">${a.application_number}</div>
                  <div class="text-[11px] text-slate-500">${a.institution_name} &bull; ${a.type}</div>
                </div>
                <span class="badge badge-warning text-[10px]">${a.status}</span>
              </div>
            `).join('')}
          ` : ''}
        `;
        resultsBox.classList.remove('hidden');
      }, 300);
    });

    document.addEventListener('click', (e) => {
      if (!input.contains(e.target) && !resultsBox.contains(e.target)) {
        resultsBox.classList.add('hidden');
      }
    });
  },

  selectSearchResult(route, param) {
    const resultsBox = document.getElementById('global-search-results');
    const input = document.getElementById('global-search-input');
    if (resultsBox) resultsBox.classList.add('hidden');
    if (input) input.value = '';
    this.navigate(route, param);
  },

  setupModals() {
    const backdrop = document.getElementById('modal-backdrop');
    if (backdrop) {
      backdrop.addEventListener('click', (e) => {
        if (e.target === backdrop) this.closeModal();
      });
    }
  },

  showModal(title, bodyHtml, buttons = []) {
    const backdrop = document.getElementById('modal-backdrop');
    const modalTitle = document.getElementById('modal-title');
    const modalBody = document.getElementById('modal-body');
    const modalFooter = document.getElementById('modal-footer');
    if (!backdrop || !modalTitle || !modalBody || !modalFooter) return;

    modalTitle.textContent = title;
    modalBody.innerHTML = bodyHtml;

    modalFooter.innerHTML = buttons.map(btn => `
      <button class="btn ${btn.class || 'btn-secondary'} text-xs font-semibold" onclick="${btn.onclick}">
        ${btn.label}
      </button>
    `).join('');

    backdrop.classList.remove('hidden');
    backdrop.classList.add('flex');
  },

  closeModal() {
    const backdrop = document.getElementById('modal-backdrop');
    if (backdrop) {
      backdrop.classList.add('hidden');
      backdrop.classList.remove('flex');
    }
  },

  toast(message, type = 'info') {
    const container = document.getElementById('toast-container');
    if (!container) return;

    const toast = document.createElement('div');
    const styles = {
      success: 'bg-emerald-800 text-white border-l-4 border-emerald-400',
      error: 'bg-red-800 text-white border-l-4 border-red-400',
      warning: 'bg-amber-800 text-white border-l-4 border-amber-400',
      info: 'bg-navy-900 text-white border-l-4 border-blue-400'
    }[type] || 'bg-navy-900 text-white';

    toast.className = `p-3 rounded shadow-lg flex items-center justify-between text-xs font-medium animate-fade-in ${styles}`;
    toast.innerHTML = `
      <div class="flex items-center gap-2">
        <span>${message}</span>
      </div>
      <button class="ml-4 text-white opacity-60 hover:opacity-100" onclick="this.parentElement.remove()">&times;</button>
    `;

    container.appendChild(toast);
    setTimeout(() => {
      toast.classList.add('opacity-0', 'transition-opacity');
      setTimeout(() => toast.remove(), 300);
    }, 4000);
  },

  toggleSidebar() {
    const sidebar = document.getElementById('sidebar');
    if (sidebar) {
      sidebar.classList.toggle('mobile-open');
    }
  }
};

window.App = App;

document.addEventListener('DOMContentLoaded', () => {
  App.init();
});
